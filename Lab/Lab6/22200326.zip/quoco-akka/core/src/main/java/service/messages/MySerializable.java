package service.messages;

public interface MySerializable {
}
