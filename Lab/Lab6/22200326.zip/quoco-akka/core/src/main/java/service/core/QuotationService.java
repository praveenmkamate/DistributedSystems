package service.core;

public interface QuotationService {
    public Quotation generateQuotation(ClientInfo info);
}
